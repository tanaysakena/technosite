<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Techno-Infosec</title>
    <link rel="icon" type="image/png" href="images/logo.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between">
                <div class="flex space-x-7">
                    <div>
                        <a href="index.php" class="flex items-center py-4">
                            <span class="font-bold text-2xl text-blue-600">Techno-Infosec</span>
                        </a>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-3">
                    <a href="index.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Home</a>
                    <a href="about.php" class="py-4 px-2 text-blue-600 font-semibold">About</a>
                    <a href="index.php#services" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Services</a>
                    <a href="index.php#training" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Training</a>
                    <a href="index.php#consulting" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Consulting</a>
                    <a href="index.php#careers" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Careers</a>
                    <a href="index.php#contact" class="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-500 transition duration-300">Contact Us</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- About Hero Section -->
    <section class="pt-32 pb-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div class="container mx-auto px-4">
            <div class="text-center text-white">
                <h1 class="text-4xl md:text-6xl font-bold mb-6">About Techno-Infosec</h1>
                <p class="text-xl opacity-90">Empowering the Future Through Technology</p>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div class="p-6 bg-white rounded-lg shadow-lg">
                    <div class="text-4xl font-bold text-blue-600 mb-2">50+</div>
                    <div class="text-xl text-gray-700">Happy Customers & Trainees</div>
                </div>
                <div class="p-6 bg-white rounded-lg shadow-lg">
                    <div class="text-4xl font-bold text-blue-600 mb-2">6+</div>
                    <div class="text-xl text-gray-700">Training Programs</div>
                </div>
                <div class="p-6 bg-white rounded-lg shadow-lg">
                    <div class="text-4xl font-bold text-blue-600 mb-2">100%</div>
                    <div class="text-xl text-gray-700">Satisfaction Rate</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Mission & Vision Section -->
    <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
                <!-- Mission -->
                <div class="modern-card p-8 bg-white">
                    <div class="flex items-center mb-6">
                        <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-bullseye text-white text-xl"></i>
                        </div>
                        <h2 class="text-3xl font-bold">Our Mission</h2>
                    </div>
                    <p class="text-gray-700 leading-relaxed">
                        To provide innovative, secure, and scalable IT solutions while delivering high-quality training programs to empower professionals.
                    </p>
                    <div class="mt-6 space-y-4">
                        <div class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Industry-leading IT solutions</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Professional training programs</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Continuous innovation</span>
                        </div>
                    </div>
                </div>

                <!-- Vision -->
                <div class="modern-card p-8 bg-white">
                    <div class="flex items-center mb-6">
                        <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-eye text-white text-xl"></i>
                        </div>
                        <h2 class="text-3xl font-bold">Our Vision</h2>
                    </div>
                    <p class="text-gray-700 leading-relaxed">
                        To become a global leader in IT solutions and cybersecurity, helping businesses and individuals harness the power of technology securely and efficiently.
                    </p>
                    <div class="mt-6 space-y-4">
                        <div class="flex items-center">
                            <i class="fas fa-star text-blue-600 mr-3"></i>
                            <span>Global technology leadership</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-star text-blue-600 mr-3"></i>
                            <span>Security-first approach</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-star text-blue-600 mr-3"></i>
                            <span>Empowering digital transformation</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold mb-4">Follow Us</h3>
                <div class="flex justify-center space-x-6">
                    <a href="https://www.facebook.com/technoinfosec" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-facebook text-2xl"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/techno-infosec/" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-linkedin text-2xl"></i>
                    </a>
                </div>
            </div>
            <div class="text-center">
                <p>&copy; 2025 Techno-Infosec. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>

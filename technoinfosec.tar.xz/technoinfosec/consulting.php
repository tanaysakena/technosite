<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulting & Admissions - Techno-Infosec</title>
    <link rel="icon" type="image/png" href="images/logo.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between">
                <div class="flex space-x-7">
                    <div>
                        <a href="index.php" class="flex items-center py-4">
                            <span class="font-bold text-2xl text-blue-600">Techno-Infosec</span>
                        </a>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-3">
                    <a href="index.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Home</a>
                    <a href="about.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">About</a>
                    <a href="services.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Services</a>
                    <a href="training.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Training</a>
                    <a href="consulting.php" class="py-4 px-2 text-blue-600 font-semibold">Consulting</a>
                    <a href="#contact" class="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-500 transition duration-300">Contact Us</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Consulting Hero Section -->
    <section class="pt-32 pb-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div class="container mx-auto px-4">
            <div class="text-center text-white">
                <h1 class="text-4xl md:text-6xl font-bold mb-6">Consulting & Admissions</h1>
                <p class="text-xl opacity-90">Your Gateway to Higher Education</p>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <section class="py-20">
        <div class="container mx-auto px-4">
            <!-- Introduction -->
            <div class="max-w-4xl mx-auto text-center mb-16">
                <p class="text-xl text-gray-700 leading-relaxed">
                    Looking to pursue higher education while balancing work and life? Techno-Infosec provides expert consulting 
                    and admission assistance for distance and online UG & PG programs from reputed universities.
                </p>
            </div>

            <!-- Available Courses -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
                <div class="modern-card p-6 text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">Bachelor's & Master's Programs</h3>
                    <ul class="text-gray-600 space-y-2">
                        <li>BA Programs</li>
                        <li>BSc Programs</li>
                        <li>BBA Programs</li>
                        <li>MBA Programs</li>
                        <li>MSc Programs</li>
                    </ul>
                </div>

                <div class="modern-card p-6 text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-laptop-code text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">IT & Computer Science</h3>
                    <ul class="text-gray-600 space-y-2">
                        <li>Computer Science</li>
                        <li>Information Technology</li>
                        <li>Software Engineering</li>
                        <li>Data Science</li>
                        <li>Cybersecurity</li>
                    </ul>
                </div>

                <div class="modern-card p-6 text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-chart-line text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">Business & Management</h3>
                    <ul class="text-gray-600 space-y-2">
                        <li>Business Administration</li>
                        <li>Finance Management</li>
                        <li>Marketing Management</li>
                        <li>HR Management</li>
                        <li>Project Management</li>
                    </ul>
                </div>

                <div class="modern-card p-6 text-center">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-certificate text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">Technical Certifications</h3>
                    <ul class="text-gray-600 space-y-2">
                        <li>Cloud Computing</li>
                        <li>Digital Marketing</li>
                        <li>Web Development</li>
                        <li>Network Security</li>
                        <li>Data Analytics</li>
                    </ul>
                </div>
            </div>

            <!-- Why Choose Us -->
            <div class="bg-white rounded-2xl shadow-lg p-8 mb-20">
                <h2 class="text-3xl font-bold text-center mb-12">Why Choose Us?</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    <div class="text-center">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-user-graduate text-2xl text-blue-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold mb-3">Personalized Recommendations</h3>
                        <p class="text-gray-600">Tailored course and university suggestions based on your goals</p>
                    </div>

                    <div class="text-center">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-tasks text-2xl text-blue-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold mb-3">Hassle-Free Admission</h3>
                        <p class="text-gray-600">Complete assistance throughout the admission process</p>
                    </div>

                    <div class="text-center">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-check-circle text-2xl text-blue-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold mb-3">Accreditation Guidance</h3>
                        <p class="text-gray-600">Expert advice on course accreditation and recognition</p>
                    </div>

                    <div class="text-center">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-headset text-2xl text-blue-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold mb-3">Continuous Support</h3>
                        <p class="text-gray-600">Dedicated support throughout your academic journey</p>
                    </div>
                </div>
            </div>

            <!-- Contact Info -->
            <div class="bg-gray-100 py-16">
                <div class="container mx-auto px-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
                        <div>
                            <i class="fas fa-map-marker-alt text-4xl text-blue-600 mb-4"></i>
                            <h3 class="text-xl font-bold mb-2">Location</h3>
                            <p class="text-gray-600">Raipur, Chhattisgarh</p>
                        </div>
                        <div>
                            <i class="fas fa-envelope text-4xl text-blue-600 mb-4"></i>
                            <h3 class="text-xl font-bold mb-2">Email</h3>
                            <p class="text-gray-600">techno.infosec4@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Get Guidance Section -->
            <div class="max-w-2xl mx-auto">
                <div class="modern-card p-8 text-center">
                    <h2 class="text-3xl font-bold text-center mb-8">Get Expert Guidance</h2>
                    <a href="mailto:techno.infosec4@gmail.com?subject=Need%20guidance%20related%20to%20course%20or%20admission" class="inline-block py-3 px-6 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-500 transition duration-300">
                        Get Guidance
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold mb-4">Follow Us</h3>
                <div class="flex justify-center space-x-6">
                    <a href="https://www.facebook.com/technoinfosec" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-facebook text-2xl"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/techno-infosec/" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-linkedin text-2xl"></i>
                    </a>
                </div>
            </div>
            <div class="text-center">
                <p>&copy; 2025 Techno-Infosec. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "techno.infosec4@gmail.com";
    
    if (isset($_POST['form_type'])) {
        switch ($_POST['form_type']) {
            case 'enroll':
                // Enroll form submission
                $course = $_POST['course'];
                $name = $_POST['name'];
                $email = $_POST['email'];
                $phone = $_POST['phone'];
                
                $subject = "New Course Enrollment Request: " . $course;
                $message = "Course Enrollment Details:\n\n";
                $message .= "Course: " . $course . "\n";
                $message .= "Name: " . $name . "\n";
                $message .= "Email: " . $email . "\n";
                $message .= "Phone: " . $phone . "\n";
                
                $headers = "From: " . $email . "\r\n";
                break;
                
            case 'quick_contact':
                // Quick contact form submission
                $name = $_POST['name'];
                $phone = $_POST['phone'];
                $query = $_POST['message'];
                
                $subject = "New Quick Contact Request";
                $message = "Quick Contact Details:\n\n";
                $message .= "Name: " . $name . "\n";
                $message .= "Phone: " . $phone . "\n";
                $message .= "Query:\n" . $query . "\n";
                
                $headers = "From: noreply@technoinfosec.com\r\n";
                break;
        }
        
        if(mail($to, $subject, $message, $headers)) {
            echo json_encode(['status' => 'success', 'message' => 'Email sent successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to send email']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid form type']);
    }
    exit;
}
?>

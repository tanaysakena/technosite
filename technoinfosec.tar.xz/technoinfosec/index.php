<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Techno-Infosec - IT Solutions & Training Company</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="images/logo.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between">
                <div class="flex space-x-7">
                    <div>
                        <a href="index.php" class="flex items-center py-4">
                            <span class="font-bold text-2xl text-blue-600">Techno-Infosec</span>
                        </a>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-3">
                    <a href="index.php" class="py-4 px-2 text-blue-600 font-semibold">Home</a>
                    <a href="about.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">About</a>
                    <a href="services.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Services</a>
                    <a href="training.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Training</a>
                    <a href="consulting.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Consulting</a>
                    <a href="mailto:techno.infosec4@gmail.com" class="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-500 transition duration-300">Contact Us</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="pt-32 pb-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div class="text-white">
                    <h1 class="text-4xl md:text-6xl font-bold mb-6">Welcome to Techno-Infosec</h1>
                    <p class="text-xl mb-8 opacity-90">Empowering Businesses with Cutting-Edge IT Solutions and Training</p>
                    <div class="space-x-4">
                        <a href="services.php" class="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-300">Our Services</a>
                        <a href="training.php" class="border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition duration-300">Training Programs</a>
                    </div>
                </div>
                <div class="hidden md:block">
                    <img src="images/soft.png" alt="IT Solutions" class="w-full">
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold">Why Choose Us?</h2>
                <p class="text-gray-600 mt-4">Experience excellence in IT solutions and training</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="text-center p-6">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-users text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">Industry Experts</h3>
                    <p class="text-gray-600">Learn from professionals with years of industry experience</p>
                </div>
                <div class="text-center p-6">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-laptop-code text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">Hands-on Training</h3>
                    <p class="text-gray-600">Practical experience with real-world projects</p>
                </div>
                <div class="text-center p-6">
                    <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-shield-alt text-2xl text-blue-600"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-4">Secure Solutions</h3>
                    <p class="text-gray-600">Enterprise-grade security for your business</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Links -->
    <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Services -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <h3 class="text-2xl font-bold mb-6">Our Services</h3>
                    <ul class="space-y-4">
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Web Development</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Cloud Computing</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Cybersecurity</span>
                        </li>
                    </ul>
                    <a href="services.php" class="inline-block mt-6 text-blue-600 hover:text-blue-800">Learn More →</a>
                </div>

                <!-- Training -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <h3 class="text-2xl font-bold mb-6">Training Programs</h3>
                    <ul class="space-y-4">
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>AWS Cloud Computing</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>DevOps</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Cybersecurity</span>
                        </li>
                    </ul>
                    <a href="training.php" class="inline-block mt-6 text-blue-600 hover:text-blue-800">View Courses →</a>
                </div>

                <!-- Consulting -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <h3 class="text-2xl font-bold mb-6">Consulting</h3>
                    <ul class="space-y-4">
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Education Consulting</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Admission Assistance</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                            <span>Career Guidance</span>
                        </li>
                    </ul>
                    <a href="consulting.php" class="inline-block mt-6 text-blue-600 hover:text-blue-800">Get Help →</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Info -->
    <div class="bg-gray-100 py-16">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
                <div>
                    <i class="fas fa-map-marker-alt text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Location</h3>
                    <p class="text-gray-600">Raipur, Chhattisgarh</p>
                </div>
                <div>
                    <i class="fas fa-envelope text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Email</h3>
                    <p class="text-gray-600">techno.infosec4@gmail.com</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Modal -->
    <div id="contactModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="bg-white p-8 max-w-md mx-auto mt-20 rounded-lg">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-bold">Contact Us</h3>
                <button onclick="closeContactModal()" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="quickContactForm" class="space-y-4">
                <div>
                    <label class="block text-gray-700 mb-2">Name *</label>
                    <input type="text" name="name" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 mb-2">Query *</label>
                    <textarea name="message" required rows="4" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500"></textarea>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300">
                    Send Message
                </button>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold mb-4">Follow Us</h3>
                <div class="flex justify-center space-x-6">
                    <a href="https://www.facebook.com/technoinfosec" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-facebook text-2xl"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/techno-infosec/" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-linkedin text-2xl"></i>
                    </a>
                </div>
            </div>
            <div class="text-center">
                <p>&copy; 2025 Techno-Infosec. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script src="js/forms.js"></script>
    <script>
        function openContactModal() {
            document.getElementById("contactModal").classList.remove("hidden");
        }

        function closeContactModal() {
            document.getElementById("contactModal").classList.add("hidden");
        }
    </script>
</body>
</html>

function openEnrollForm(courseName) {
    const modal = document.getElementById('enrollModal');
    const courseInput = document.getElementById('courseInput');
    courseInput.value = courseName;
    modal.style.display = 'block';
}

function closeEnrollForm() {
    const modal = document.getElementById('enrollModal');
    modal.style.display = 'none';
}

function closeContactModal() {
    const modal = document.getElementById('contactModal');
    modal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    // Handle Enroll Form Submit
    const enrollForm = document.getElementById('enrollForm');
    if (enrollForm) {
        enrollForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('form_type', 'enroll');
            
            fetch('includes/send_mail.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Enrollment request sent successfully!');
                    closeEnrollForm();
                    this.reset();
                } else {
                    alert('Failed to send enrollment request. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    }

    // Handle Quick Contact Form Submit
    const quickContactForm = document.getElementById('quickContactForm');
    if (quickContactForm) {
        quickContactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('form_type', 'quick_contact');
            
            fetch('includes/send_mail.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Message sent successfully!');
                    closeContactModal();
                    this.reset();
                } else {
                    alert('Failed to send message. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    }
});

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Techno-Infosec - Services</title>
    <link rel="icon" type="image/png" href="images/logo.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between">
                <div class="flex space-x-7">
                    <div>
                        <a href="index.php" class="flex items-center py-4">
                            <span class="font-bold text-2xl text-blue-600">Techno-Infosec</span>
                        </a>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-3">
                    <a href="index.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Home</a>
                    <a href="about.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">About</a>
                    <a href="services.php" class="py-4 px-2 text-blue-600 font-semibold">Services</a>
                    <a href="training.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Training</a>
                    <a href="consulting.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Consulting</a>
                    <a href="#contact" class="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-500 transition duration-300">Contact Us</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Services Hero Section -->
    <section class="pt-32 pb-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div class="container mx-auto px-4">
            <div class="text-center text-white">
                <h1 class="text-4xl md:text-6xl font-bold mb-6">Our Services</h1>
                <p class="text-xl opacity-90">Comprehensive IT Solutions for Your Business</p>
            </div>
        </div>
    </section>

    <!-- Services Grid -->
    <section class="py-20">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Web Development -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <div class="service-icon mb-6">
                        <i class="fas fa-code"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">Web Development</h3>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Custom Website Development</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Web Applications</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>E-commerce Solutions</span>
                        </li>
                    </ul>
                </div>

                <!-- Cloud Computing -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <div class="service-icon mb-6">
                        <i class="fas fa-cloud"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">Cloud Computing</h3>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>AWS Solutions</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Terraform Infrastructure</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Scalable Cloud Solutions</span>
                        </li>
                    </ul>
                </div>

                <!-- DevOps -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <div class="service-icon mb-6">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">DevOps</h3>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>CI/CD Pipelines</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Automation Solutions</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Infrastructure as Code</span>
                        </li>
                    </ul>
                </div>

                <!-- Digital Marketing -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <div class="service-icon mb-6">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">Digital Marketing</h3>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>SEO Optimization</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>PPC Campaigns</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Social Media Marketing</span>
                        </li>
                    </ul>
                </div>

                <!-- Cybersecurity -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <div class="service-icon mb-6">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">Cybersecurity</h3>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Penetration Testing</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Threat Analysis</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>OSINT Investigations</span>
                        </li>
                    </ul>
                </div>

                <!-- IT Training -->
                <div class="modern-card p-8 hover:shadow-xl transition-shadow">
                    <div class="service-icon mb-6">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">IT Training</h3>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>AWS & Cloud Computing</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>DevOps & Cybersecurity</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                            <span>Web Development</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Info -->
    <div class="bg-gray-100 py-16" id="contact">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
                <div>
                    <i class="fas fa-map-marker-alt text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Location</h3>
                    <p class="text-gray-600">Raipur, Chhattisgarh</p>
                </div>
                <div>
                    <i class="fas fa-envelope text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Email</h3>
                    <p class="text-gray-600">techno.infosec4@gmail.com</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold mb-4">Follow Us</h3>
                <div class="flex justify-center space-x-6">
                    <a href="https://www.facebook.com/technoinfosec" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-facebook text-2xl"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/techno-infosec/" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-linkedin text-2xl"></i>
                    </a>
                </div>
            </div>
            <div class="text-center">
                <p>&copy; 2025 Techno-Infosec. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>

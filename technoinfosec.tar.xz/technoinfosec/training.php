<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Training Programs - Techno-Infosec</title>
    <link rel="icon" type="image/png" href="images/logo.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between">
                <div class="flex space-x-7">
                    <div>
                        <a href="index.php" class="flex items-center py-4">
                            <span class="font-bold text-2xl text-blue-600">Techno-Infosec</span>
                        </a>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-3">
                    <a href="index.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Home</a>
                    <a href="about.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">About</a>
                    <a href="services.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Services</a>
                    <a href="training.php" class="py-4 px-2 text-blue-600 font-semibold">Training</a>
                    <a href="consulting.php" class="py-4 px-2 text-gray-600 hover:text-blue-600 transition duration-300">Consulting</a>
                    <a href="#contact" class="py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-500 transition duration-300">Contact Us</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Enrollment Modal -->
    <div id="enrollModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="bg-white p-8 max-w-md mx-auto mt-20 rounded-lg">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-bold">Enroll Now</h3>
                <button onclick="closeEnrollForm()" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="enrollForm" class="space-y-4">
                <input type="hidden" id="courseInput" name="course">
                <div>
                    <label class="block text-gray-700 mb-2">Name *</label>
                    <input type="text" name="name" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 mb-2">Email *</label>
                    <input type="email" name="email" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 mb-2">Phone *</label>
                    <input type="tel" name="phone" required class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500">
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300">
                    Submit Enrollment
                </button>
            </form>
        </div>
    </div>

    <!-- Training Hero Section -->
    <section class="pt-32 pb-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div class="container mx-auto px-4">
            <div class="text-center text-white">
                <h1 class="text-4xl md:text-6xl font-bold mb-6">Training Programs</h1>
                <p class="text-xl opacity-90">Comprehensive IT Training for Professional Growth</p>
            </div>
        </div>
    </section>

    <!-- Training Programs Grid -->
    <section class="py-20">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Cloud Computing -->
                <div class="modern-card hover:shadow-xl transition-shadow">
                    <div class="relative">
                        <img src="images/aws.jpg" alt="AWS Cloud Training" class="w-full h-64 object-cover rounded-t-lg">
                        <div class="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 m-2 rounded-full text-sm">
                            Most Popular
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-4">Cloud Computing</h3>
                        <ul class="space-y-3 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>AWS Architecture</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Cloud Infrastructure</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>AWS Services</span>
                            </li>
                        </ul>
                        <button onclick="openEnrollForm('Cloud Computing')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">
                            Enroll Now
                        </button>
                    </div>
                </div>

                <!-- DevOps -->
                <div class="modern-card hover:shadow-xl transition-shadow">
                    <div class="relative">
                        <img src="images/devops.jpg" alt="DevOps Training" class="w-full h-64 object-cover rounded-t-lg">
                        <div class="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 m-2 rounded-full text-sm">
                            Trending
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-4">DevOps</h3>
                        <ul class="space-y-3 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>CI/CD Pipelines</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Docker & Kubernetes</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Infrastructure as Code</span>
                            </li>
                        </ul>
                        <button onclick="openEnrollForm('DevOps')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">
                            Enroll Now
                        </button>
                    </div>
                </div>

                <!-- Web Development -->
                <div class="modern-card hover:shadow-xl transition-shadow">
                    <div class="relative">
                        <img src="images/webtech.jpg" alt="Web Development Training" class="w-full h-64 object-cover rounded-t-lg">
                        <div class="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 m-2 rounded-full text-sm">
                            Popular
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-4">Web Development</h3>
                        <ul class="space-y-3 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Full Stack Development</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Modern Frameworks</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Database Design</span>
                            </li>
                        </ul>
                        <button onclick="openEnrollForm('Web Development')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">
                            Enroll Now
                        </button>
                    </div>
                </div>

                <!-- OSINT -->
                <div class="modern-card hover:shadow-xl transition-shadow">
                    <div class="relative">
                        <img src="images/osint.jpg" alt="OSINT Training" class="w-full h-64 object-cover rounded-t-lg">
                        <div class="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 m-2 rounded-full text-sm">
                            New
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-4">OSINT & Threat Intelligence</h3>
                        <ul class="space-y-3 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Information Gathering</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Threat Analysis</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Digital Footprinting</span>
                            </li>
                        </ul>
                        <button onclick="openEnrollForm('OSINT & Threat Intelligence')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">
                            Enroll Now
                        </button>
                    </div>
                </div>

                <!-- Database -->
                <div class="modern-card hover:shadow-xl transition-shadow">
                    <div class="relative h-64">
                        <img src="images/mysql.png" alt="Database Training" class="w-full h-full object-contain p-4 rounded-t-lg">
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-4">Database (MySQL)</h3>
                        <ul class="space-y-3 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Database Design</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>SQL Queries</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Database Administration</span>
                            </li>
                        </ul>
                        <button onclick="openEnrollForm('Database (MySQL)')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">
                            Enroll Now
                        </button>
                    </div>
                </div>

                <!-- Digital Marketing -->
                <div class="modern-card hover:shadow-xl transition-shadow">
                    <div class="relative">
                        <img src="images/dm.png" alt="Digital Marketing Training" class="w-full h-64 object-cover rounded-t-lg">
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-4">Digital Marketing</h3>
                        <ul class="space-y-3 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>SEO & SEM</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Social Media Marketing</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-3"></i>
                                <span>Content Strategy</span>
                            </li>
                        </ul>
                        <button onclick="openEnrollForm('Digital Marketing')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">
                            Enroll Now
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Info -->
    <div class="bg-gray-100 py-16">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
                <div>
                    <i class="fas fa-map-marker-alt text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Location</h3>
                    <p class="text-gray-600">Raipur, Chhattisgarh</p>
                </div>
                <div>
                    <i class="fas fa-envelope text-4xl text-blue-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Email</h3>
                    <p class="text-gray-600">techno.infosec4@gmail.com</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold mb-4">Follow Us</h3>
                <div class="flex justify-center space-x-6">
                    <a href="https://www.facebook.com/technoinfosec" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-facebook text-2xl"></i>
                    </a>
                    <a href="https://www.linkedin.com/company/techno-infosec/" target="_blank" class="text-white hover:text-blue-400 transition-colors">
                        <i class="fab fa-linkedin text-2xl"></i>
                    </a>
                </div>
            </div>
            <div class="text-center">
                <p>&copy; 2025 Techno-Infosec. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Add JavaScript -->
    <script src="js/forms.js"></script>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

    <script>
    document.querySelectorAll('.modern-card').forEach(card => {
        const title = card.querySelector('h3').textContent;
        const enrollBtn = card.querySelector('a[href="#contact"]');
        if (enrollBtn) {
            enrollBtn.outerHTML = `<button onclick="openEnrollForm('${title}')" class="block text-center w-full bg-blue-600 text-white py-3 px-6 rounded-lg mt-6 hover:bg-blue-700 transition duration-300 font-semibold">Enroll Now</button>`;
        }
    });
    </script>
</body>
</html>
